package com.ez.zalopatch;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import com.ez.zalopatch.xposed.core.XpLog;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class HookConfig {
    private static final Uri PROVIDER_URI = Uri.parse("content://com.ez.zalopatch.config/prefs");
    private static final String MODULE_PACKAGE = "com.ez.zalopatch";
    private static final Map<String, String> cache = new ConcurrentHashMap<>();
    private static volatile ConfigSnapshot snapshot;
    private static volatile ConfigSnapshot legacySnapshot;
    private static volatile boolean legacySnapshotChecked;
    private static volatile boolean legacySnapshotInvalid;
    private static volatile Map<String, String> legacySettings;
    private static volatile NotificationRuleStore.RuleSet legacyRules;
    private static volatile boolean authoritative;
    private static volatile boolean remoteInitialized;
    private static volatile boolean providerSnapshotChecked;
    private static volatile String snapshotSource = "legacy";
    private static volatile Context appContext;
    private static volatile Context moduleContext;
    private static volatile boolean moduleContextUnavailable;
    private static volatile NotificationRuleStore.RuleSet notificationRules;
    private static volatile Boolean hookDebugEnabled;

    private HookConfig() {
    }

    public interface RemoteConfig {
        long properties() throws Throwable;
        String readSnapshot() throws Throwable;
    }

    public static synchronized void initRemote(RemoteConfig framework) {
        if (remoteInitialized) return;
        remoteInitialized = true;
        try {
            if (ConfigSnapshot.remoteSupported(framework.properties(), 2L)) {
                authoritative = true;
                snapshotSource = "remote-unavailable";
                snapshot = ConfigSnapshot.decode(framework.readSnapshot(), BuildConfig.VERSION_CODE);
                if (snapshot != null) snapshotSource = "framework-remote";
            }
        } catch (Throwable error) {
            // A remote-capable framework must never revive a stale legacy snapshot on IPC failure.
            authoritative = true;
            snapshotSource = "remote-unavailable";
        }
    }

    public static boolean hasAuthoritativeSnapshot() { return authoritative; }

    public static String snapshotSource() { return snapshotSource; }

    public static String snapshotId() {
        return authoritative ? (snapshot == null ? "" : snapshot.id)
                : legacySnapshot == null ? "" : legacySnapshot.id;
    }

    public static String readBlob(String key) {
        if (!authoritative && legacySnapshot != null && NotificationRuleStore.MIRROR_KEY.equals(key)) {
            return legacySnapshot.values.get(key);
        }
        return ConfigSnapshot.value(snapshot, authoritative, key,
                () -> SettingsPropertyMirror.readBlob(key));
    }

    public static void init() {
        loadLegacySnapshot();
        if (hookDebugEnabled == null) {
            synchronized (HookConfig.class) {
                if (hookDebugEnabled == null) {
                    hookDebugEnabled = readDebugEnabled();
                }
            }
        }
    }

    public static void setAppContext(Context context) {
        if (context != null) {
            Context applicationContext = context.getApplicationContext();
            appContext = applicationContext != null ? applicationContext : context;
            moduleContext = null;
            moduleContextUnavailable = false;
            loadProviderSnapshot();
            reload();
            freezeLegacySettings();
        }
    }

    private static synchronized void loadLegacySnapshot() {
        if (authoritative || legacySnapshotChecked) return;
        legacySnapshotChecked = true;
        String encoded = SettingsPropertyMirror.readBlob(ConfigSnapshot.LEGACY_KEY);
        if (encoded != null || SettingsPropertyMirror.hasBlobMarker(ConfigSnapshot.LEGACY_KEY)) {
            legacySnapshot = ConfigSnapshot.decodeProperty(encoded, BuildConfig.VERSION_CODE,
                    SettingsPropertyMirror.readBlob(NotificationRuleStore.MIRROR_KEY));
            legacySnapshotInvalid = legacySnapshot == null;
            snapshotSource = legacySnapshot == null ? "property-unavailable" : "property-snapshot";
        }
    }

    private static synchronized void freezeLegacySettings() {
        if (authoritative || legacySettings != null) return;
        loadLegacySnapshot();
        Map<String, String> loaded = new java.util.HashMap<>();
        for (Settings.Setting<?> setting : Settings.all()) {
            String value = legacySnapshotInvalid ? null : readValue(appContext, setting.key);
            loaded.put(setting.key, value == null ? String.valueOf(setting.defaultValue) : value);
        }
        legacyRules = legacySnapshotInvalid ? NotificationRuleStore.RuleSet.empty() : notificationRules();
        legacySettings = java.util.Collections.unmodifiableMap(loaded);
    }

    private static synchronized void loadProviderSnapshot() {
        if (authoritative || providerSnapshotChecked) return;
        providerSnapshotChecked = true;
        String encoded = readFromProvider(resolveModuleContext(appContext), ConfigSnapshot.KEY, "module");
        if (encoded == null) encoded = readFromProvider(appContext, ConfigSnapshot.KEY, "target");
        if (encoded != null) {
            authoritative = true;
            snapshot = ConfigSnapshot.decode(encoded, BuildConfig.VERSION_CODE);
            snapshotSource = snapshot == null ? "provider-unavailable" : "provider-snapshot";
        }
    }

    public static void reload() {
        cache.clear();
        notificationRules = null;
    }

    public static NotificationRuleStore.RuleSet notificationRules() {
        if (!authoritative && legacyRules != null) return legacyRules;
        NotificationRuleStore.RuleSet cached = notificationRules;
        if (cached != null) {
            return cached;
        }
        synchronized (HookConfig.class) {
            cached = notificationRules;
            if (cached == null) {
                String propertyJson = readBlob(
                        NotificationRuleStore.MIRROR_KEY);
                String providerJson = !authoritative && propertyJson == null
                        ? readValue(appContext, NotificationRuleStore.PREF_KEY) : null;
                cached = NotificationRuleStore.resolve(propertyJson, providerJson);
                notificationRules = cached;
            }
        }
        return cached;
    }

    public static void logStartupSnapshot() {
        if (authoritative) {
            XpLog.i("ZaloPatch: HookConfig snapshot source=" + snapshotSource
                    + " id=" + snapshotId() + " generation="
                    + (snapshot == null ? -1 : snapshot.generation) + " keys="
                    + (snapshot == null ? 0 : snapshot.values.size()));
            return;
        }
        Context context = appContext;
        if (context == null) {
            XpLog.i("ZaloPatch: HookConfig snapshot source=none appContext=false");
            return;
        }
        int count = 0;
        try {
            Context providerContext = resolveModuleContext(context);
            String source = providerContext != null ? "module-provider" : "target-provider";
            if (providerContext == null) {
                providerContext = context;
            }
            Cursor cursor = providerContext.getContentResolver().query(
                    PROVIDER_URI, null, null, null, null);
            if (cursor != null) {
                try {
                    while (cursor.moveToNext()) {
                        count++;
                    }
                } finally {
                    cursor.close();
                }
            }
            XpLog.i("ZaloPatch: HookConfig snapshot source=" + source + " keys=" + count);
        } catch (Throwable throwable) {
            XpLog.i("ZaloPatch: HookConfig snapshot provider failed: "
                    + throwable.getClass().getSimpleName() + " " + throwable.getMessage());
        }
    }

    public static boolean isEnabled(String key) {
        String value = readValue(appContext, key);
        if (value == null) {
            return Settings.defaultBoolean(key);
        }
        if ("true".equalsIgnoreCase(value)) {
            return true;
        }
        if ("false".equalsIgnoreCase(value)) {
            return false;
        }
        return Settings.defaultBoolean(key);
    }

    public static int getLevel(String key) {
        String value = readValue(appContext, key);
        if (value == null) {
            return Settings.defaultInt(key);
        }
        try {
            return Settings.coerceInt(key, Integer.parseInt(value));
        } catch (NumberFormatException ignored) {
            return Settings.defaultInt(key);
        }
    }

    public static int getLevel(Context context, String key) {
        String value = readValue(context, key);
        if (value == null) {
            return Settings.defaultInt(key);
        }
        try {
            return Settings.coerceInt(key, Integer.parseInt(value));
        } catch (NumberFormatException ignored) {
            return Settings.defaultInt(key);
        }
    }

    public static boolean getRawBoolean(String key, boolean fallback) {
        String value = readValue(appContext, key);
        if (value == null) {
            return fallback;
        }
        if ("true".equalsIgnoreCase(value)) {
            return true;
        }
        if ("false".equalsIgnoreCase(value)) {
            return false;
        }
        return fallback;
    }

    public static long getRawLong(String key, long fallback) {
        String value = readValue(appContext, key);
        if (value == null) {
            return fallback;
        }
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public static String getRawString(String key, String fallback) {
        String value = readValue(appContext, key);
        return value == null ? fallback : value;
    }

    private static String readValue(Context context, String key) {
        if (authoritative) return ConfigSnapshot.value(snapshot, true, key, () -> null);
        if (Settings.find(key) != null) {
            if (legacySettings != null) return legacySettings.get(key);
            if (legacySnapshot != null) return legacySnapshot.values.get(key);
            if (legacySnapshotInvalid) return null;
        }
        String cached = cache.get(key);
        if (cached != null) {
            return cached;
        }
        String propertyValue = SettingsPropertyMirror.read(key);
        if (propertyValue != null) {
            cache.put(key, propertyValue);
            return propertyValue;
        }
        // LibXposed API 102 modules cannot use XSharedPreferences: the world-readable
        // prefs fallback is gone. Reads before any application context exists use the
        // fail-safe defaults at the call site; once a context exists the module
        // provider is the structured fallback after the property mirror.
        if (context == null) {
            context = resolveFallbackContext();
        }
        if (context == null) {
            return null;
        }
        String value = readFromProvider(resolveModuleContext(context), key, "module");
        if (value != null) {
            return value;
        }
        return readFromProvider(context, key, "target");
    }

    private static String readFromProvider(Context context, String key, String source) {
        if (context == null) {
            return null;
        }
        try {
            Cursor cursor = context.getContentResolver().query(Uri.withAppendedPath(PROVIDER_URI, key), null, null, null, null);
            if (cursor == null) {
                return null;
            }
            try {
                int valueIndex = cursor.getColumnIndex("value");
                if (valueIndex >= 0 && cursor.moveToFirst()) {
                    String value = cursor.getString(valueIndex);
                    if (value != null) {
                        cache.put(key, value);
                    }
                    return value;
                }
            } finally {
                cursor.close();
            }
        } catch (Throwable throwable) {
            if (isDebugEnabled()) {
                android.util.Log.i("ZaloPatch", "Provider read failed source=" + source
                        + " key=" + key + " " + throwable.getClass().getSimpleName());
            }
        }
        return null;
    }

    private static Context resolveModuleContext(Context baseContext) {
        Context cached = moduleContext;
        if (cached != null) {
            return cached;
        }
        if (moduleContextUnavailable) {
            return null;
        }
        if (baseContext == null) {
            return null;
        }
        try {
            cached = baseContext.createPackageContext(MODULE_PACKAGE, Context.CONTEXT_IGNORE_SECURITY);
            moduleContext = cached;
            return cached;
        } catch (Throwable throwable) {
            moduleContextUnavailable = true;
            android.util.Log.i("ZaloPatch", "Module context unavailable: "
                    + throwable.getClass().getSimpleName());
            return null;
        }
    }

    /**
     * Dev debug toggle, backed by an Android system property (readable by any app at any time,
     * unlike the prefs/ContentProvider path which is SELinux-blocked / unreliable cross-process).
     * Toggle from the host with no rebuild:
     *     adb shell setprop debug.zalopatch 1   # enable lightweight debug diagnostics
     *     adb shell setprop debug.zalopatch 0   # disable
     * Then restart Zalo. The "debug." prefix is shell-settable without root and survives until
     * reboot. Works at any call site, including process-start.
     */
    public static boolean isDebugEnabled() {
        Boolean cached = hookDebugEnabled;
        return cached != null ? cached : readDebugEnabled();
    }

    /** Reads the live gate for exported diagnostic receivers. */
    public static boolean isDebugCurrentlyEnabled() {
        return readDebugEnabled();
    }

    private static boolean readDebugEnabled() {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            String value = (String) sp.getMethod("get", String.class, String.class)
                    .invoke(null, "debug.zalopatch", "0");
            return "1".equals(value) || "true".equalsIgnoreCase(value);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static Context resolveFallbackContextForHooks() {
        return appContext != null ? appContext : resolveFallbackContext();
    }

    public static Context resolveModuleContextForHooks() {
        Context context = resolveFallbackContextForHooks();
        Context module = resolveModuleContext(context);
        return module != null ? module : context;
    }

    private static Context resolveFallbackContext() {
        try {
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            Context context = (Context) activityThreadClass.getMethod("currentApplication").invoke(null);
            if (context != null) {
                return context;
            }
            Object activityThread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
            if (activityThread != null) {
                return (Context) activityThreadClass.getMethod("getSystemContext").invoke(activityThread);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}
